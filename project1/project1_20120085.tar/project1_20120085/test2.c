/* comment /* asdf *****/

/* com**

    /


    ment */

/*commerror /*
